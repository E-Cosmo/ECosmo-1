<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['item-options:popup-size:row']     = 'small'; // small, medium, large
$cfg['item-options:popup-size:column']  = 'small';
$cfg['item-options:popup-size:item']    = 'small';
$cfg['item-options:popup-size:default'] = 'small';

<?php if (!defined('FW')) die('Forbidden');

// MegaMenu row options
$options = array(
	'bg-image' => array(
		'label'       => esc_html__( 'Background Image', 'olympus' ),
		'type'        => 'upload',
		'images_only' => true,
	),
);
<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}
/**
 * Theme config
 *
 * @var array $cfg Fill this array with configuration data
 */

$cfg['extensions_blacklist'] = array( /* 'extension_name', 'extension_name' */ );

//$cfg['settings_form_ajax_submit'] = false;

$cfg['settings_form_side_tabs'] = true;
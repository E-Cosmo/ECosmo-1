Olympus WordPress theme is a fully responsive theme that looks great on any devices including iPad, iPhone or any other mobile device.

== Installation ==
Manual installation:

1. Upload the `olympus` folder to the `/wp-content/themes/` directory

== Supported Browser ==
Mozilla Firefox, Google Chrome, Safari, IE 11

== Version history ==
1.0 – Base functional